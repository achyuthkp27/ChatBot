import time

import psycopg2

from config import config


def mask_card_number(crd_num):
    masked = ''.join(['*' if char.isdigit() else char for char in crd_num[:-4]]) + crd_num[-4:]
    return ' '.join(masked[i:i + 4] for i in range(0, len(masked), 4))


def CreditCardConnect():
    connection = None
    try:
        params = config()
        print('Connecting to the postgreSQL database ...')
        connection = psycopg2.connect(**params)
        cursor = connection.cursor()

        select_query: str = "select card_type ,card_number ,balance,card_holder from chatbot.credit_card_list where party_id='1058'"
        cursor.execute(select_query)
        records = cursor.fetchall()

        print(records)
        
        credit_cards = []
        for row in records:
            credit_card = {
                "card_type": row[0],
                "card_number": mask_card_number(row[1]),
                "card_balance": row[2],
                "card_holder_name": row[3]
            }
            credit_cards.append(credit_card)
        cursor.close()
        return {"credit_cards_list": credit_cards}
    except(Exception, psycopg2.DatabaseError) as error:
        print(f'Error during database connection: {error}')
    finally:
        if connection is not None:
            connection.close()
            print('Database connection terminated.')
