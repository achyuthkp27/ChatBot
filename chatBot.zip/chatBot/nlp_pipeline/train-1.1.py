import json
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from model import NeuralNetwork
from nltk_lib import tokenizer, stemming, bag_of_words
 
# Load intents data
with open("./nlp_pipeline/training data/intents.json", 'r') as file:
    intents = json.load(file)
 
# Extract words, tags, and xy data
all_words = []
tags = []
xy = []
 
for intent in intents['intents']:
    tag = intent['tag']
    tags.append(tag)
    for pattern in intent['patterns']:
        _tokenize = tokenizer(pattern)
        all_words.extend(_tokenize)
        xy.append((_tokenize, tag))
 
ignore_words = ['?', '!', '.', ',']
all_words = [stemming(i) for i in all_words if i not in ignore_words]
all_words = sorted(set(all_words))
 
train_x = []
train_y = []
for (tokenized_sentence, tag) in xy:
    bag = bag_of_words(tokenized_sentence, all_words)
    train_x.append(bag)
 
    label = tags.index(tag)
    train_y.append(label)  # CrossEntropyloss
 
train_x = np.array(train_x)
train_y = np.array(train_y)
 
# Splitting data into train and validation sets
X_train, X_val, y_train, y_val = train_test_split(train_x, train_y, test_size=0.1, random_state=42)
 
# Define Dataset and DataLoader
class ChatDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.from_numpy(X).float()
        self.y = torch.from_numpy(y).long()
 
    def __len__(self):
        return len(self.X)
 
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]
 
train_dataset = ChatDataset(X_train, y_train)
train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
 
# Hyperparameters
input_size = len(all_words)
hidden_size = 16  # Increased hidden layer size
output_size = len(tags)
learning_rate = 0.001
num_epochs = 1500  # Extended to 1500 epochs for better convergence
 
# Initialize model, criterion, and optimizer
model = NeuralNetwork(input_size, hidden_size, output_size)
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)  # Added weight decay for regularization
 
# Training loop
for epoch in range(num_epochs):
    model.train()  # Set model to training mode
    for inputs, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
 
    if (epoch + 1) % 100 == 0:
        # Optionally, evaluate on validation data here and print validation loss/accuracy
        print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')
 
# Save trained model
torch.save({
    'model_state_dict': model.state_dict(),
    'all_words': all_words,
    'tags': tags
}, "./nlp_pipeline/data.pth")
 
print("Training complete. Model saved.")