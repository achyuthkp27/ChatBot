import psycopg2

from config import config

user_data = {
    "account_number": None,
    "delivery_options": None,
    "chequebook_size": None,
    "otp_check": None,
    "otp_count": 0
}

delivery_options = ['collect in branch', 'delivery to address', 'address', 'branch', '1', '2']
chequebook_sizes = ['25', '50', '75', '1', '2', '3']


def ClearInputs():
    user_data["account_number"] = None
    user_data["delivery_options"] = None
    user_data["chequebook_size"] = None
    user_data["otp_check"] = None
    user_data["otp_count"] = 0


def ChequeBookReq(ip: str):
    if user_data['otp_count'] >= 3:
        return "Maximum OTP Attempts reached. Please try again after sometime"
    if ip is None and user_data['account_number'] is None:
        return "Please Provide your Account Number or send '<b>Abort</b>' to stop the process"
    elif user_data['account_number'] is None:
        if ip == "289131966543" or ip == "335131962556":
            if checkChequeBook(ip):
                return "Cheque Book Order Already Exist for this Account Number"
            user_data['account_number'] = ip
            return "Please Provide Delivery Details: <p> 1. Collect in Branch</p><p> 2. Delivery to Address</p>"
        else:
            return "Invalid Account Details provided. Please Enter your Account Number"
    elif user_data['delivery_options'] is None:
        if ip.lower() in delivery_options:
            user_data['delivery_options'] = ip
            return "Please Provide Number of Cheque Leaves required <p> 1. 25</p><p> 2. 50</p> <p>3. 75</p>"
        else:
            return "Invalid Details Provided. Please Enter a Delivery Option"
    elif user_data['chequebook_size'] is None:
        if ip.isdigit() and ip in chequebook_sizes:
            user_data['chequebook_size'] = ip
            return "We have sent an OTP to your Registered device. Please enter the sent OTP"
        else:
            return "Invalid Details Provided. Please Enter a Valid Cheque Leave Size"
    elif user_data['otp_check'] is None:
        if ip.isdigit() and ip == "567876":
            user_data['otp_check'] = ip
            ChequeBookConnect()
            return "Completed"
        else:
            user_data['otp_count'] = user_data['otp_count'] + 1
            return "Invalid OTP Provided"
    return "Completed"


def checkChequeBook(ip):
    connection = None
    try:
        params = config()
        print('Connecting to the postgreSQL database ...')
        connection = psycopg2.connect(**params)
        cursor = connection.cursor()

        select_query: str = "select party_id from chatbot.cheque_order_details where party_id=%s and account_number=%s"
        cursor.execute(select_query, ("1058", ip))
        records = cursor.fetchone()
        cursor.close()
        return len(records) != 0
    except(Exception, psycopg2.DatabaseError) as error:
        print(f'Error during database connection: {error}')
    finally:
        if connection is not None:
            connection.close()
            print('Database connection terminated.')


def ChequeBookConnect():
    connection = None
    try:
        params = config()
        print('Connecting to the postgreSQL database ...')
        connection = psycopg2.connect(**params)
        cursor = connection.cursor()

        insert_query: str = "insert into chatbot.cheque_order_details(party_id,account_number,delivery_option,leaves) values (%s, %s, %s, %s)"

        deliveryOption = 'Collect in Branch' if user_data['delivery_options'] in ['collect in branch', 'branch',
                                                                                  '1'] else 'Delivery to Address'
        size = user_data['chequebook_size']
        if size in ['1', '25']:
            chequeLeave = "25"
        elif size in ['2', '50']:
            chequeLeave = "50"
        elif size in ['3', '75']:
            chequeLeave = "75"
        cursor.execute(insert_query,
                       ("1058", user_data['account_number'], deliveryOption,
                        chequeLeave))
        connection.commit()
        cursor.close()
    except(Exception, psycopg2.DatabaseError) as error:
        print(f'Error during database connection: {error}')
    finally:
        if connection is not None:
            connection.close()
            print('Database connection terminated.')
        user_data["account_number"] = None
        user_data["delivery_options"] = None
        user_data["chequebook_size"] = None
        user_data["otp_check"] = None
        user_data["otp_count"] = 0


def ChequeBookDetails():
    connection = None
    try:
        params = config()
        print('Connecting to the postgreSQL database ...')
        connection = psycopg2.connect(**params)
        cursor = connection.cursor()

        cursor.execute(
            "select account_number,delivery_option,leaves,order_date from chatbot.cheque_order_details where party_id='1058'")
        records = cursor.fetchall()
        print(records)
        cursor.close()
        connection.close()

        if len(records) == 0:
            return "No Cheque Book Order History Found"
        else:
            header = "<h4 class=cheque-book>Cheque Book Order Details</h4><br><div class=container>"
            row = "<div class=cheque-details><div class=detail><span class=label>Account Number:</span> <span class=value>{}</span></div><div class=detail><span class=label>Cheque Book Size:</span> <span class=value>{}</span></div><div class=detail><span class=label>Delivery Option:</span> <span class=value>{}</span></div><div class=detail><span class=label>Ordered Date:</span> <span class=value>{}</span></div></div><br><br>"
            end = "</div>"
            finalRow = ""
            for i in records:
                print(i)
                finalRow = finalRow + row.format(i[0], i[2], i[1], i[3])
            return header + finalRow + end
    except(Exception, psycopg2.DatabaseError) as error:
        print(f'Error during database connection: {error}')
    finally:
        if connection is not None:
            connection.close()
            print('Database connection terminated.')
